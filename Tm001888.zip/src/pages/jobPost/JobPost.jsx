import React from "react";
import "./jobpost.css"

export default function JobPost() {
    return (
        <form action="">
            <h5>Job post</h5>
        </form>
    )
}